import jaydebeapi
import pandas as pd
import os
from pathlib import Path
import jpype


class database_connection(object):
    __JAR_FILE_PATH = os.path.join(Path(__file__).parent.parent, 'JAR')

    def __init__(self, username, password, db_name=None):
        """
        :param username: Database username (String)
        :param password: Database password (String)
        :param db_name: Database name (Optional)
        """
        self.username = username
        self.password = password
        self.db_name = db_name

    def oracle_jdbc_connection(self, conn_str, driver, classpath_jar):
        """
        :param conn_str: connection string (jdbc:oracle:thin:@host:port/service)
        :param driver: driver details (oracle.jdbc.driver.OracleDriver)
        :param classpath_jar: ojdbc(n).jar
        :return: connection object and cursor
        """
        try:
            classpath = os.path.join(type(self).__JAR_FILE_PATH, classpath_jar)
            jpype.startJVM(jpype.getDefaultJVMPath(), f"-Djava.class.path={classpath}")
            jdbc_connection = jaydebeapi.connect(driver, conn_str, [self.username, self.password])
        except Exception as jdbc_error:
            print('Error connection oracle, Error Found {}'.format(jdbc_error))
        else:
            return jdbc_connection, jdbc_connection.cursor()

    def mysql_connection(self, host, port):
        """
        :param host: host_name
        :param port: port_name
        :return: connection object and cursor
        """
        try:
            # Connection string in format: host:port
            import mysql.connector
            mysql_connection = mysql.connector.connect(host=host, port=int(port), user=self.username,
                                                       password=self.password, database=self.db_name)
        except Exception as mysql_error:
            print('Error connecting mysql, Error Found: {}', format(mysql_error))
        else:
            return mysql_connection, mysql_connection.cursor()

    def sql_server_connection(self, conn_string):
        """
        :param conn_string: conn_string
        :return: connection object
        """
        try:
            # Connection string in format: host:port
            import pyodbc
            sql_server_connection = pyodbc.connect(conn_string)
        except Exception as sql_server_error:
            print('Error connecting SQL SERVER, Error Found: {}', format(mysql_error))
        else:
            return sql_server_connection

    def oracle_connection(self, conn_str):
        """
        :param conn_str: host:port/service
        :return: connection object and cursor
        """
        try:
            import cx_Oracle
            oracle_connection = cx_Oracle.connect(str(self.username), str(self.password), conn_str)
        except Exception as oracle_error:
            print('Error connecting oracle, Error Found: {}'.format(oracle_error))
        else:
            return oracle_connection, oracle_connection.cursor()

    @staticmethod
    def execute_query(query_str, connection):
        """
        :param query_str: SQL query
        :param connection: connection object
        :return: DataFrame of queryset result
        """
        try:
            df = pd.io.sql.read_sql(query_str, connection)
            return df
        except Exception as db_error:
            print("Exception: Unable to execute query, Error Found: {}".format(db_error))
