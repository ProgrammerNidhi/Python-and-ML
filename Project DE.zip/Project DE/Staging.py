#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import csv
import sqlalchemy
import sqlalchemy.ext.declarative
import psycopg2 as pg
import io
import pandas as pd
import pyodbc
import mysql.connector


class postgres(object):
def __init__(self, conn_str,table_name):
self._conn_str = conn_str
self._engine = sqlalchemy.create_engine(self._conn_str)
self.tablename = table_name


def insert(self, df):
conn = self._engine.raw_connection()
c = conn.cursor()
print(c)
print(self.tablename)
sio = io.StringIO()
df.to_csv(sio, header=False, index=False, sep='|')
sio.seek(0)
try:
c.copy_from(sio, self.tablename, null='',sep = '|')
conn.commit()
except (pg.errors.UniqueViolation):
pass


def delete(self, df, uid_column):
with self._engine.connect() as conn:
for i, row in df.iterrows():
conn.execute('DELETE FROM {table} WHERE {uid_col} = {uid}'.format(table=self.tablename, uid_col=uid_column, uid=row[uid_column]))


def truncate(self):
with self._engine.connect() as conn:
conn.execute('delete from {table}'.format(table=self.tablename))


def clean_columns(self, columns):
return [col.replace(' ', '_') for col in columns]




def postgres_resource(context):
return postgres(
context.resource_config['conn_str'],context.resource_config['table_name']
)



def postgres_insert(context, df):
context.log.info('Insert rows to table: based on unique column ID.')
context.resources.postgres.insert(df)



def postgres_delete(context, df, uid_column='uid'):
context.log.info('Delete rows from table: based on unique column ID: {uid}'.format(uid=uid_column))
context.resources.postgres.delete(df, uid_column)


def get_data_mysql(context,conn_string_mysql,query):
try:
#Connection in format "host:port:username:password:database"
conn_details = conn_string_mysql.split(':')
cnx = mysql.connector.connect(user=conn_details[2], password=conn_details[3],
                              host=conn_details[0],port = conn_details[1],
                              database=conn_details[4],auth_plugin='mysql_native_password')
except:
print('Exception Arise ')

else:
print('Connected ...')
df= pd.io.sql.read_sql(query,cnx)
print(df.head(3))
return df



def sql_server_pipeline():
df = get_data_mysql()
#postgres_delete(df)
postgres_insert(df)


if __name__ == '__main__':
pg_user = ''
pg_pwd = ''
pg_host = ''
pg_db = ''
pg_table = ''

proxy_host  = ''
proxy_port = ''
tablename = 'test_covid19_dash_datasets'
conn_str_postgres = 'postgresql+psycopg2://username:password#@142.63.219.250/database'
conn_string_mysql = "btlp007139:3308:svc_cio_metrics:swU37a#hko2q:dashboards"
query = """SELECT * FROM table"""

