#Steps to connect to the database#

1. Run the first code to establish a connection between postgresql and Python.
   (Code mentioned in the file database_connection)
2. This code is written as a generic way to connect to any database. The connection details for postgresql need to be given in 
def postgresql_connection(self, host, port):
        """
        :param host: host_name
        :param port: port_name
        :return: connection object and cursor
        """
        try:
            # Connection string in format: host:port
            import mysql.connector
            mysql_connection = mysql.connector.connect(host=host, port=int(port), user=self.username,
                                                       password=self.password, database=self.db_name)
Pass the parameters of your connection in the code above.
A connection object will be returned which will set up a connection between the python and postgresql.

Note: This code is written as a generic code to connect to any type of database.

#Create the Enterprise Layer tables#

1. The DDLs for the datavalult named as smdvault is shared in the code. You can uncomment all of them and execute.
   The tables (hubs and satellites ) will be created on running those DDLs. 
   This step needs to be performed before reading and inserting the data in the staging layer.

#Steps to execute the staging code#

1. We are going to read the files and insert the data into the tables present in the enterprise layer.
2. Ensure to install these libraries in your system. Steps of installation of mysql.connector and psycopg2 are present in the doc folder.

import os
import csv
import sqlalchemy
import sqlalchemy.ext.declarative
import psycopg2 as pg
import io
import pandas as pd
import pyodbc
import mysql.connector

3. There are parameters to be passed at the bottom of the code.

Pass the below parameters:
if __name__ == '__main__':
pg_user = ''
pg_pwd = ''
pg_host = ''
pg_db = ''
pg_table = ''

proxy_host  = ''
proxy_port = ''
tablename1 = ''
tablename2 = ''
tablename3 = ''
tablename4 = ''
tablename5 = ''
tablename6 = ''
conn_str_postgres = 'postgresql+psycopg2://username:password#@142.63.219.250/database'
conn_string_mysql = "btlp007139:3308:svc_cio_metrics:swU37a#hko2q:dashboards"
query1 = "SELECT * FROM table"
query2="SELECT * FROM table"
query3="SELECT * FROM table"
query4="SELECT * FROM table"
query5="SELECT * FROM table"
query6="SELECT * FROM table"

As many times you would want to load the table and the files, you can pass the names of the files as a parameter.
example: tablename6 = 'hubexperiment' query6="SELECT * FROM hubexperiment"

This code will read the files on the server and load them into the enterprise layer tables.

#Information layer#

Information layers act as the Data mart which is built only to perform the analysis. 
The views which are the data only of a certain type are created on top of the actual table with an underlying query. 
You can perform joins, union, etc operations for the data analysis, and only a certain type of data can be presented as a view in order to ensure security and better performance of the vault. It can further be used for the reporting.



