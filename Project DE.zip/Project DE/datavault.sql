/*Creation of the database smdvault */
--create database smdvault

/*Creation of the table hubexperiment -added a column experiment*/

-- CREATE TABLE hubexperiment (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   experiment varchar(255),
--   PRIMARY KEY (sequence));
  
/*Select query to view the created table*/
-- select * from hubexperiment;

/*Creation of the table satexperimenttitle */

-- CREATE TABLE satexperimenttitle (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   title VARCHAR(255) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubexperiment(sequence));

/*Select query to view the created table*/
-- select * from satexperimenttitle;

-- /*Creation of the table satexperimentacronym */

-- CREATE TABLE satexperimentacronym (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   acronym VARCHAR(15) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubexperiment(sequence));

/*Select query to view the created table*/
-- select * from satexperimentacronym;

/*Creation of the table hubtreatment-added a column treatment*/

-- CREATE TABLE hubtreatment (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   experiment VARCHAR(255) not null,
--   treatment VARCHAR(255),
--   PRIMARY KEY (sequence));

/*Select query to view the created table*/
-- select * from hubtreatment;

/*Creation of the table hubexperimentalunit */	

-- CREATE TABLE hubexperimentalunit (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   PRIMARY KEY (sequence));

/*Select query to view the created table*/
-- select * from hubexperimentalunit;

/*Creation of the table hubsubject */	

-- CREATE TABLE hubsubject (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   name VARCHAR(40),
--   PRIMARY KEY (sequence));

/*Select query to view the created table*/
-- select * from hubsubject;

/*Creation of the table satsubjectage */

-- CREATE TABLE satsubjectage (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   age int,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubsubject(sequence));

/*Select query to view the created table*/
-- select * from satsubjectage;

/*Creation of the table satsubjectname */

-- CREATE TABLE satsubjectname (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   name varchar(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubsubject(sequence));

/*Select query to view the created table*/
-- select * from satsubjectname;

/*Creation of the table satgender-created a new table*/

-- CREATE TABLE satgender (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   name varchar(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubsubject(sequence));

/*Select query to view the created table*/
-- select * from satgender;

/*Creation of the table hubmetadata */	

-- CREATE TABLE hubmetadata (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   PRIMARY KEY (sequence));

/*Select query to view the created table*/
-- select * from hubmetadata;

/*Creation of the table satmetadatakeyvaluepair */

-- CREATE TABLE satmetadatakeyvaluepair (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   key varchar(40) not null,
--   value oid,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubmetadata (sequence));

/*Select query to view the created table*/
-- select * from satmetadatakeyvaluepair;

/*Creation of the table hubsession */

-- CREATE TABLE hubsession (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   PRIMARY KEY (sequence));
  
/*Select query to view the created table*/
-- select * from hubsession;

/*Creation of the table satsessionname */

-- CREATE TABLE satsessionname (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   name varchar(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubsession(sequence));
  
/*Select query to view the created table*/
-- select * from satsessionname;

/*Creation of the table participatesin */

-- CREATE TABLE participatesin (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   experimentalunit VARCHAR(40) not null,
--   experiment varchar(40) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (experimentalunit) REFERENCES hubexperimentalunit(sequence),
--   FOREIGN KEY (experiment) REFERENCES hubexperimentalunit(sequence));

/*Select query to view the created table*/
-- select * from participatesin;

/*Creation of the table satexperimentunitidentifier */

-- CREATE TABLE satexperimentunitidentifier (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   id VARCHAR(15),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES participatesin(sequence));

/*Select query to view the created table*/
-- select * from satexperimentunitidentifier;

/*Creation of the table hubgroup */

-- CREATE TABLE hubgroup (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   treatment VARCHAR(15) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (treatment) REFERENCES hubtreatment(sequence));

/*Select query to view the created table*/
-- select * from hubgroup;

/*Creation of the table satgroupname */

-- CREATE TABLE satgroupname (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   name VARCHAR(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubgroup(sequence));
 
/*Select query to view the created table*/
-- select * from satgroupname;

/*Creation of the table assignedto */

-- CREATE TABLE assignedto (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   experimentalunit VARCHAR(40) not null,
--   "group" VARCHAR(40) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (experimentalunit) REFERENCES hubexperimentalunit(sequence),
--   FOREIGN KEY ("group") REFERENCES hubgroup(sequence));

/*Select query to view the created table*/
-- select * from assignedto;

/*Creation of the table hubfactor */

-- CREATE TABLE hubfactor (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   experiment VARCHAR(15) not null,
--   iscofactor bool default false,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (experiment) REFERENCES hubexperiment(sequence));
  
/*Select query to view the created table*/
-- select * from hubfactor;

/*Creation of the table satfactorname */

-- CREATE TABLE satfactorname (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   name VARCHAR(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubfactor(sequence));

/*Select query to view the created table*/
-- select * from satfactorname;

/*Creation of the table satfactorlevel */

-- CREATE TABLE satfactorlevel (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   levelvalue VARCHAR(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubfactor(sequence));

/*Select query to view the created table*/
-- select * from satfactorlevel;

/*Creation of the table sattreatmentfactorlevel */

-- CREATE TABLE sattreatmentfactorlevel (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   levelvalue VARCHAR(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubfactor(sequence));

/*Select query to view the created table*/
-- select * from sattreatmentfactorlevel;

/*Creation of the table attendssession */

-- CREATE TABLE attendssession (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   experimentalunit VARCHAR(40) not null,
--   "group" VARCHAR(40) not null,
--   session VARCHAR(40) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (experimentalunit) REFERENCES hubexperimentalunit(sequence),
--   FOREIGN KEY ("group") REFERENCES hubgroup(sequence),
--   FOREIGN KEY (session) REFERENCES hubfactor(sequence));

/*Select query to view the created table*/
-- select * from attendssession;

/*Creation of the table sessionmetadata */

-- CREATE TABLE sessionmetadata (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   session VARCHAR(40) not null,
--   metadata VARCHAR(40) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (session) REFERENCES hubsession(sequence),
--   FOREIGN KEY (metadata) REFERENCES hubmetadata(sequence));
  
/*Select query to view the created table*/
-- select * from sessionmetadata;

/*Creation of the table hubobservation */

-- CREATE TABLE hubobservation (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   collectedatsession VARCHAR(40) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (collectedatsession) REFERENCES hubsession(sequence));

/*Select query to view the created table*/
-- select * from hubobservation;

/*Creation of the table satobservationname */

-- CREATE TABLE satobservationname (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   name VARCHAR(40),
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubobservation(sequence));

/*Select query to view the created table*/
-- select * from satobservationname;

/*Creation of the table satobservationname */

-- CREATE TABLE satobservationvalue (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   value int[],
--   timestamps time[],
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (sequence) REFERENCES hubobservation(sequence));
  
/*Select query to view the created table*/
-- select * from satobservationvalue;

/*Creation of the table observationmetadata */

-- CREATE TABLE observationmetadata (
--   sequence varchar(20) NOT NULL,
--   timestamp time NOT NULL unique,
--   source varchar(255) NOT NULL unique,
--   observation VARCHAR(40) not null,
--   metadata VARCHAR(40) not null,
--   PRIMARY KEY (sequence),
--   FOREIGN KEY (observation) REFERENCES hubobservation(sequence),
--   FOREIGN KEY (metadata) REFERENCES hubmetadata(sequence));

/*Select query to view the created table*/
-- select * from observationmetadata;
	



    
 